/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.In;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class WordNet {
    private final Map<String, Set<Integer>> nounToSynsets;
    private final List<String> synsetList;
    private final Digraph wordNetGraph;
    private final SAP sap;

    public WordNet(String synsets, String hypernyms) {
        // Initialisation des structures de données
        nounToSynsets = new HashMap<>();
        synsetList = new ArrayList<>();

        // Lire et construire les synsets
        readSynsets(synsets);

        // Créer un graphe avec le nombre de synsets comme nombre de sommets
        wordNetGraph = new Digraph(synsetList.size());

        // Lire et construire les hypernyms
        readHypernyms(hypernyms);

        // Créer l'objet SAP
        sap = new SAP(wordNetGraph);
    }

    private void readSynsets(String synsetsFile) {
        In in = new In(synsetsFile);
        while (in.hasNextLine()) {
            String[] fields = in.readLine().split(",");
            int id = Integer.parseInt(fields[0]);
            String[] nouns = fields[1].split(" ");
            synsetList.add(fields[1]); // Synset complet
            for (String noun : nouns) {
                if (!nounToSynsets.containsKey(noun)) {
                    nounToSynsets.put(noun, new HashSet<>());
                }
                nounToSynsets.get(noun).add(id);
            }
        }
    }

    private void readHypernyms(String hypernymsFile) {
        In in = new In(hypernymsFile);
        while (in.hasNextLine()) {
            String[] fields = in.readLine().split(",");
            int synsetId = Integer.parseInt(fields[0]);
            for (int i = 1; i < fields.length; i++) {
                int hypernymId = Integer.parseInt(fields[i]);
                wordNetGraph.addEdge(synsetId, hypernymId);
            }
        }
    }

    public Iterable<String> nouns() {
        return nounToSynsets.keySet();
    }

    public boolean isNoun(String word) {
        return nounToSynsets.containsKey(word);
    }

    public int distance(String nounA, String nounB) {
        if (!isNoun(nounA) || !isNoun(nounB)) throw new IllegalArgumentException("Invalid noun");
        Set<Integer> synsetsA = nounToSynsets.get(nounA);
        Set<Integer> synsetsB = nounToSynsets.get(nounB);
        return sap.length(synsetsA, synsetsB);
    }

    public String sap(String nounA, String nounB) {
        if (!isNoun(nounA) || !isNoun(nounB)) throw new IllegalArgumentException("Invalid noun");
        Set<Integer> synsetsA = nounToSynsets.get(nounA);
        Set<Integer> synsetsB = nounToSynsets.get(nounB);
        int ancestorId = sap.ancestor(synsetsA, synsetsB);
        return ancestorId == -1 ? null : synsetList.get(ancestorId);
    }

    public static void main(String[] args) {
        WordNet wordNet = new WordNet(args[0], args[1]);
        System.out.println("Number of nouns: " + wordNet.nouns());
    }
}
