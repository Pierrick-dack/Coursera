/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.In;

public class Outcast {
    private final WordNet wordNet;

    public Outcast(WordNet wordNet) {
        this.wordNet = wordNet;
    }

    public String outcast(String[] nouns) {
        int maxDistance = -1;
        String outcast = null;
        for (String nounA : nouns) {
            int distanceSum = 0;
            for (String nounB : nouns) {
                if (!nounA.equals(nounB)) {
                    distanceSum += wordNet.distance(nounA, nounB);
                }
            }
            if (distanceSum > maxDistance) {
                maxDistance = distanceSum;
                outcast = nounA;
            }
        }
        return outcast;
    }

    public static void main(String[] args) {
        WordNet wordNet = new WordNet(args[0], args[1]);
        Outcast outcast = new Outcast(wordNet);
        for (int t = 2; t < args.length; t++) {
            In in = new In(args[t]);
            String[] nouns = in.readAllStrings();
            System.out.println(args[t] + ": " + outcast.outcast(nouns));
        }
    }
}

