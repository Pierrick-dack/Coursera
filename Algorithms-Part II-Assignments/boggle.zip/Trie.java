/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import java.util.HashMap;

public class Trie {
    private class Node {
        private boolean isWord = false;
        private HashMap<Character, Node> next = new HashMap<>();
    }

    private final Node root = new Node();

    // Ajouter un mot dans le Trie
    public void add(String word) {
        Node node = root;
        for (char c : word.toCharArray()) {
            node = node.next.computeIfAbsent(c, k -> new Node());
        }
        node.isWord = true;
    }

    // Vérifier si un mot est dans le Trie
    public boolean contains(String word) {
        Node node = getNode(word);
        return node != null && node.isWord;
    }

    // Vérifier si un préfixe est valide dans le Trie
    public boolean hasPrefix(String prefix) {
        return getNode(prefix) != null;
    }

    // Méthode pour obtenir le noeud correspondant à un mot ou préfixe
    private Node getNode(String word) {
        Node node = root;
        for (char c : word.toCharArray()) {
            if (!node.next.containsKey(c)) {
                return null;
            }
            node = node.next.get(c);
        }
        return node;
    }
}

