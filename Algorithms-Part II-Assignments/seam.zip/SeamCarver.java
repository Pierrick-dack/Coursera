/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.Picture;

import java.awt.Color;

public class SeamCarver {
    private Picture picture;

    // create a seam carver object based on the given picture
    public SeamCarver(Picture picture) {
        if (picture == null) throw new IllegalArgumentException("Picture is null");
        this.picture = new Picture(picture); // Ne pas muter l'image d'origine
    }

    // Current picture
    public Picture picture() {
        return new Picture(picture);
    }

    // Width of current picture
    public int width() {
        return picture.width();
    }

    // Height of current picture
    public int height() {
        return picture.height();
    }

    // energy of pixel at column x and row y
    public double energy(int x, int y) {
        if (x < 0 || x >= width() || y < 0 || y >= height())
            throw new IllegalArgumentException("Invalid pixel coordinates");

        // Bordures : énergie définie à 1000
        if (x == 0 || y == 0 || x == width() - 1 || y == height() - 1) {
            return 1000.0;
        }

        // Calcul du gradient pour x et y
        double deltaX2 = gradientSquared(x - 1, y, x + 1, y);
        double deltaY2 = gradientSquared(x, y - 1, x, y + 1);

        return Math.sqrt(deltaX2 + deltaY2);
    }

    // Calcul du gradient au carré entre deux pixels
    private double gradientSquared(int x1, int y1, int x2, int y2) {
        Color color1 = picture.get(x1, y1);
        Color color2 = picture.get(x2, y2);

        int redDiff = color1.getRed() - color2.getRed();
        int greenDiff = color1.getGreen() - color2.getGreen();
        int blueDiff = color1.getBlue() - color2.getBlue();

        return redDiff * redDiff + greenDiff * greenDiff + blueDiff * blueDiff;
    }

    // sequence of indices for horizontal seam
    public int[] findHorizontalSeam() {
        Picture transposedPicture = transposePicture();
        SeamCarver transposedSeamCarver = new SeamCarver(transposedPicture);
        return transposedSeamCarver.findVerticalSeam();
    }

    // sequence of indices for vertical seam
    public int[] findVerticalSeam() {
        int width = width();
        int height = height();
        double[][] energyMatrix = new double[height][width];
        int[][] seamPath = new int[height][width];
        double[][] distTo = new double[height][width];

        // Initialisation de l'énergie et des distances
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                energyMatrix[y][x] = energy(x, y);
                if (y == 0) {
                    distTo[y][x] = energyMatrix[y][x];
                }
                else {
                    distTo[y][x] = Double.POSITIVE_INFINITY;
                }
            }
        }

        // Relâcher les bords du graphe pour calculer les chemins minimaux
        for (int y = 0; y < height - 1; y++) {
            for (int x = 0; x < width; x++) {
                relax(x, y, distTo, energyMatrix, seamPath);
            }
        }

        // Trouver la position du chemin minimal dans la dernière ligne
        int[] seam = new int[height];
        double minDist = Double.POSITIVE_INFINITY;
        int minIndex = -1;
        for (int x = 0; x < width; x++) {
            if (distTo[height - 1][x] < minDist) {
                minDist = distTo[height - 1][x];
                minIndex = x;
            }
        }

        // Reconstituer le chemin minimal
        for (int y = height - 1; y >= 0; y--) {
            seam[y] = minIndex;
            minIndex = seamPath[y][minIndex];
        }

        return seam;
    }

    // Relâcher les bords pour un pixel donné
    private void relax(int x, int y, double[][] distTo, double[][] energyMatrix, int[][] seamPath) {
        int width = width();
        for (int i = -1; i <= 1; i++) {
            if (x + i >= 0 && x + i < width) {
                if (distTo[y + 1][x + i] > distTo[y][x] + energyMatrix[y + 1][x + i]) {
                    distTo[y + 1][x + i] = distTo[y][x] + energyMatrix[y + 1][x + i];
                    seamPath[y + 1][x + i] = x;
                }
            }
        }
    }

    // remove horizontal seam from current picture
    public void removeHorizontalSeam(int[] seam) {
        if (seam == null || seam.length != width()) {
            throw new IllegalArgumentException("Invalid horizontal seam");
        }
        Picture transposedPicture = transposePicture();
        SeamCarver transposedSeamCarver = new SeamCarver(transposedPicture);
        transposedSeamCarver.removeVerticalSeam(seam);
        this.picture = transposePicture(transposedSeamCarver.picture());
    }

    // remove vertical seam from current picture
    public void removeVerticalSeam(int[] seam) {
        if (seam == null || seam.length != height() || width() <= 1) {
            throw new IllegalArgumentException("Invalid vertical seam");
        }

        Picture newPicture = new Picture(width() - 1, height());
        for (int y = 0; y < height(); y++) {
            int newX = 0;
            for (int x = 0; x < width(); x++) {
                if (x != seam[y]) {
                    newPicture.set(newX++, y, picture.get(x, y));
                }
            }
        }
        this.picture = newPicture;
    }

    // Transpose l'image
    private Picture transposePicture() {
        Picture transposed = new Picture(height(), width());
        for (int x = 0; x < width(); x++) {
            for (int y = 0; y < height(); y++) {
                transposed.set(y, x, picture.get(x, y));
            }
        }
        return transposed;
    }

    // Transposer une image donnée
    private Picture transposePicture(Picture picture) {
        Picture transposed = new Picture(picture.height(), picture.width());
        for (int x = 0; x < picture.width(); x++) {
            for (int y = 0; y < picture.height(); y++) {
                transposed.set(y, x, picture.get(x, y));
            }
        }
        return transposed;
    }


    public static void main(String[] args) {
        // Charger l'image
        Picture picture = new Picture("6x5.png");
        System.out.println("Original image size: " + picture.width() + "x" + picture.height());

        // Créer un objet SeamCarver
        SeamCarver seamCarver = new SeamCarver(picture);

        // Tester la largeur et la hauteur de l'image
        System.out.println("Width: " + seamCarver.width());
        System.out.println("Height: " + seamCarver.height());

        // Calculer l'énergie de quelques pixels
        System.out.println("Energy at (1, 1): " + seamCarver.energy(1, 1));
        System.out.println("Energy at (2, 2): " + seamCarver.energy(2, 2));

        // Trouver le seam vertical de plus faible énergie
        int[] verticalSeam = seamCarver.findVerticalSeam();
        System.out.print("Vertical seam: ");
        for (int i : verticalSeam) {
            System.out.print(i + " ");
        }
        System.out.println();

        // Supprimer un seam vertical et tester
        seamCarver.removeVerticalSeam(verticalSeam);
        System.out.println("Image size after vertical seam removal: " + seamCarver.width() + "x"
                                   + seamCarver.height());

        // Trouver le nouveau seam horizontal après la suppression du seam vertical
        int[] newHorizontalSeam = seamCarver.findHorizontalSeam();
        System.out.print("New horizontal seam: ");
        for (int i : newHorizontalSeam) {
            System.out.print(i + " ");
        }
        System.out.println();

        // Supprimer le nouveau seam horizontal
        seamCarver.removeHorizontalSeam(newHorizontalSeam);
        System.out.println("Image size after horizontal seam removal: " + seamCarver.width() + "x"
                                   + seamCarver.height());

        // Sauvegarder l'image après modifications
        seamCarver.picture().save("resized_picture.png");
        System.out.println("Image saved as resized_picture.png");
    }

}

