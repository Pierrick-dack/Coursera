/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

import edu.princeton.cs.algs4.StdRandom;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class RandomizedQueue<Item> implements Iterable<Item> {
    private Item[] queue;
    private int n;  // taille du tableau

    // Constructeur pour initialiser une file aléatoire vide
    public RandomizedQueue() {
        queue = (Item[]) new Object[2];
        n = 0;
    }

    // Vérifier si la file aléatoire est vide
    public boolean isEmpty() {
        return n == 0;
    }

    // Retourner le nombre d'éléments dans la file aléatoire
    public int size() {
        return n;
    }

    // Ajouter un élément à la file aléatoire
    public void enqueue(Item item) {
        if (item == null) throw new IllegalArgumentException("Null item");
        if (n == queue.length) resize(2 * queue.length);  // doubler la taille si nécessaire
        queue[n++] = item;
    }

    // Retirer et retourner un élément aléatoire de la file
    public Item dequeue() {
        if (isEmpty()) throw new NoSuchElementException("Queue underflow");
        int index = StdRandom.uniformInt(n);  // choisir un index aléatoire
        Item item = queue[index];
        queue[index] = queue[--n];  // remplacer par le dernier élément
        queue[n] = null;  // éviter les références en suspens
        if (n > 0 && n == queue.length / 4) resize(queue.length / 2);
        return item;
    }

    // Retourner un élément aléatoire sans le retirer
    public Item sample() {
        if (isEmpty()) throw new NoSuchElementException("Queue underflow");
        return queue[StdRandom.uniformInt(n)];
    }

    // Redimensionner le tableau
    private void resize(int capacity) {
        Item[] copy = (Item[]) new Object[capacity];
        for (int i = 0; i < n; i++) {
            copy[i] = queue[i];
        }
        queue = copy;
    }

    // Itérateur qui retourne les éléments dans un ordre aléatoire
    public Iterator<Item> iterator() {
        return new RandomizedQueueIterator();
    }

    private class RandomizedQueueIterator implements Iterator<Item> {
        private int[] order;
        private int current;

        public RandomizedQueueIterator() {
            order = new int[n];
            for (int i = 0; i < n; i++) {
                order[i] = i;
            }
            StdRandom.shuffle(order);  // mélanger l'ordre des indices
            current = 0;
        }

        public boolean hasNext() {
            return current < n;
        }

        public Item next() {
            if (!hasNext()) throw new NoSuchElementException();
            return queue[order[current++]];
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }
    }

    // Méthode de test pour vérifier le bon fonctionnement
    public static void main(String[] args) {
        RandomizedQueue<Integer> rq = new RandomizedQueue<>();
        rq.enqueue(1);
        rq.enqueue(2);
        rq.enqueue(3);
        rq.enqueue(4);
        System.out.println(rq.dequeue());
        System.out.println(rq.sample());
    }
}
