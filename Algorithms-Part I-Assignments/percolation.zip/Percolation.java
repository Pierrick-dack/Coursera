/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    private final int n;
    private final boolean[][] grid;
    private final WeightedQuickUnionUF uf;
    private final WeightedQuickUnionUF ufFull;
    private int openSites;
    private final int virtualTop;
    private final int virtualBottom;

    // Create n-by-n grid, with all sites initially blocked
    public Percolation(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException("Grid size must be greater than 0");
        }
        this.n = n;
        grid = new boolean[n][n];
        uf = new WeightedQuickUnionUF(n * n + 2); // include virtual top and bottom
        ufFull = new WeightedQuickUnionUF(n * n + 1); // include only virtual top
        virtualTop = 0;
        virtualBottom = n * n + 1;
        openSites = 0;
    }

    // Open the site (row, col) if it is not open already
    public void open(int row, int col) {
        validate(row, col);
        if (!isOpen(row, col)) {
            grid[row - 1][col - 1] = true;
            openSites++;

            int current = xyTo1D(row, col);

            if (row == 1) {
                uf.union(virtualTop, current);
                ufFull.union(virtualTop, current);
            }
            if (row == n) {
                uf.union(virtualBottom, current);
            }
            connectAdjacent(row, col, current);
        }
    }

    // Is the site (row, col) open?
    public boolean isOpen(int row, int col) {
        validate(row, col);
        return grid[row - 1][col - 1];
    }

    // Is the site (row, col) full?
    public boolean isFull(int row, int col) {
        validate(row, col);
        return ufFull.find(virtualTop) == ufFull.find(xyTo1D(row, col));
    }

    // Number of open sites
    public int numberOfOpenSites() {
        return openSites;
    }

    // Does the system percolate?
    public boolean percolates() {
        return uf.find(virtualTop) == uf.find(virtualBottom);
    }

    private void validate(int row, int col) {
        if (row < 1 || row > n || col < 1 || col > n) {
            throw new IllegalArgumentException("Row or column index out of bounds");
        }
    }

    private int xyTo1D(int row, int col) {
        return (row - 1) * n + col;
    }

    private void connectAdjacent(int row, int col, int current) {
        if (row > 1 && isOpen(row - 1, col)) {
            uf.union(current, xyTo1D(row - 1, col));
            ufFull.union(current, xyTo1D(row - 1, col));
        }
        if (row < n && isOpen(row + 1, col)) {
            uf.union(current, xyTo1D(row + 1, col));
            ufFull.union(current, xyTo1D(row + 1, col));
        }
        if (col > 1 && isOpen(row, col - 1)) {
            uf.union(current, xyTo1D(row, col - 1));
            ufFull.union(current, xyTo1D(row, col - 1));
        }
        if (col < n && isOpen(row, col + 1)) {
            uf.union(current, xyTo1D(row, col + 1));
            ufFull.union(current, xyTo1D(row, col + 1));
        }
    }
}

