/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.FlowEdge;
import edu.princeton.cs.algs4.FlowNetwork;
import edu.princeton.cs.algs4.FordFulkerson;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BaseballElimination {
    private final int numTeams;
    private final Map<String, Integer> teamToIndex;
    private final String[] teams;
    private final int[] wins;
    private final int[] losses;
    private final int[] remaining;
    private final int[][] games;
    private final Map<String, List<String>> eliminationCertificate;

    // Constructor
    public BaseballElimination(String filename) {
        In in = new In(filename);
        numTeams = in.readInt();
        teamToIndex = new HashMap<>();
        teams = new String[numTeams];
        wins = new int[numTeams];
        losses = new int[numTeams];
        remaining = new int[numTeams];
        games = new int[numTeams][numTeams];
        eliminationCertificate = new HashMap<>();

        for (int i = 0; i < numTeams; i++) {
            String team = in.readString();
            teams[i] = team;
            teamToIndex.put(team, i);
            wins[i] = in.readInt();
            losses[i] = in.readInt();
            remaining[i] = in.readInt();
            for (int j = 0; j < numTeams; j++) {
                games[i][j] = in.readInt();
            }
        }
    }

    // Return the number of teams
    public int numberOfTeams() {
        return numTeams;
    }

    // Return the list of all teams
    public Iterable<String> teams() {
        return Arrays.asList(teams);
    }

    // Return the number of wins for a given team
    public int wins(String team) {
        validateTeam(team);
        return wins[teamToIndex.get(team)];
    }

    // Return the number of losses for a given team
    public int losses(String team) {
        validateTeam(team);
        return losses[teamToIndex.get(team)];
    }

    // Return the number of remaining games for a given team
    public int remaining(String team) {
        validateTeam(team);
        return remaining[teamToIndex.get(team)];
    }

    // Return the number of remaining games between two teams
    public int against(String team1, String team2) {
        validateTeam(team1);
        validateTeam(team2);
        return games[teamToIndex.get(team1)][teamToIndex.get(team2)];
    }

    // Check if a team is mathematically eliminated
    public boolean isEliminated(String team) {
        validateTeam(team);
        int x = teamToIndex.get(team);
        int maxPossibleWins = wins[x] + remaining[x];

        // Trivial elimination
        for (int i = 0; i < numTeams; i++) {
            if (i != x && wins[i] > maxPossibleWins) {
                eliminationCertificate.put(team, Collections.singletonList(teams[i]));
                return true;
            }
        }

        // Non-trivial elimination using MaxFlow
        FlowNetwork network = buildFlowNetwork(x);
        FordFulkerson maxflow = new FordFulkerson(network, 0, network.V() - 1);

        // Check if all game nodes are fully saturated
        for (FlowEdge edge : network.adj(0)) {
            if (edge.flow() != edge.capacity()) {
                // Non-trivial elimination, find the certificate of elimination
                List<String> certificate = new ArrayList<>();
                for (int i = 1 + (numTeams - 1) * (numTeams - 2) / 2; i < network.V() - 1; i++) {
                    if (maxflow.inCut(i)) {
                        certificate.add(teams[i - 1 - (numTeams - 1) * (numTeams - 2) / 2]);
                    }
                }
                eliminationCertificate.put(team, certificate);
                return true;
            }
        }

        return false;
    }

    // Return the certificate of elimination for a team, if any
    public Iterable<String> certificateOfElimination(String team) {
        validateTeam(team);
        return eliminationCertificate.get(team);
    }

    // Build the flow network for non-trivial elimination
    private FlowNetwork buildFlowNetwork(int x) {
        // Calculate the total number of game vertices
        int gameVertices = (numTeams - 1) * (numTeams - 2) / 2;
        int totalVertices = 1 + gameVertices + (numTeams - 1) + 1; // source, games, teams, sink

        FlowNetwork network = new FlowNetwork(totalVertices);
        int source = 0;
        int sink = totalVertices - 1;
        int gameVertexIndex = 1;
        int teamVertexIndex = 1 + gameVertices;

        int maxPossibleWins = wins[x] + remaining[x];

        // Add edges for game vertices
        for (int i = 0; i < numTeams; i++) {
            if (i == x) continue;
            for (int j = i + 1; j < numTeams; j++) {
                if (j == x) continue;
                int gamesLeft = games[i][j];
                network.addEdge(new FlowEdge(source, gameVertexIndex, gamesLeft));
                network.addEdge(new FlowEdge(gameVertexIndex, teamVertexIndex + i,
                                             Double.POSITIVE_INFINITY));
                network.addEdge(new FlowEdge(gameVertexIndex, teamVertexIndex + j,
                                             Double.POSITIVE_INFINITY));
                gameVertexIndex++;
            }
        }

        // Add edges for team vertices
        for (int i = 0; i < numTeams; i++) {
            if (i == x) continue;
            int capacity = maxPossibleWins - wins[i];
            if (capacity < 0) capacity = 0;
            network.addEdge(new FlowEdge(teamVertexIndex + i, sink, capacity));
        }

        return network;
    }

    // Helper function to validate team name
    private void validateTeam(String team) {
        if (!teamToIndex.containsKey(team)) {
            throw new IllegalArgumentException("Invalid team: " + team);
        }
    }

    // Main method to test the implementation
    public static void main(String[] args) {
        BaseballElimination division = new BaseballElimination(args[0]);
        for (String team : division.teams()) {
            if (division.isEliminated(team)) {
                StdOut.print(team + " is eliminated by the subset R = { ");
                for (String t : division.certificateOfElimination(team)) {
                    StdOut.print(t + " ");
                }
                StdOut.println("}");
            }
            else {
                StdOut.println(team + " is not eliminated");
            }
        }
    }
}

