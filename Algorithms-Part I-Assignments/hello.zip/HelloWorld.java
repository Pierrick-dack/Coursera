/* *****************************************************************************
 *  Name:              Kamela Pierrick Dack
 *  Coursera User ID:  123456
 *  Last modified:     September 3, 2024
 **************************************************************************** */

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World");
    }
}
