/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdOut;

import java.util.HashSet;
import java.util.Set;

public class BoggleSolver {

    private final Trie dictionary;

    // Constructeur : initialise le solver avec un dictionnaire donné
    public BoggleSolver(String[] dictionary) {
        this.dictionary = new Trie();
        for (String word : dictionary) {
            this.dictionary.add(word);
        }
    }

    // Méthode pour obtenir tous les mots valides sur un plateau de Boggle
    public Iterable<String> getAllValidWords(BoggleBoard board) {
        Set<String> validWords = new HashSet<>();
        boolean[][] visited = new boolean[board.rows()][board.cols()];

        // Parcourir chaque lettre du plateau
        for (int i = 0; i < board.rows(); i++) {
            for (int j = 0; j < board.cols(); j++) {
                dfs(board, i, j, "", visited, validWords);
            }
        }

        return validWords;
    }

    // DFS pour construire les mots valides
    private void dfs(BoggleBoard board, int i, int j, String prefix, boolean[][] visited,
                     Set<String> validWords) {
        // Si la position est hors limites ou si elle est déjà visitée, retour
        if (i < 0 || i >= board.rows() || j < 0 || j >= board.cols() || visited[i][j]) {
            return;
        }

        char letter = board.getLetter(i, j);
        if (letter == 'Q') {
            prefix += "QU";
        }
        else {
            prefix += letter;
        }

        // Si le mot ne commence pas par un préfixe valide, retour
        if (!dictionary.hasPrefix(prefix)) {
            return;
        }

        // Si c'est un mot valide (et assez long), l'ajouter
        if (prefix.length() > 2 && dictionary.contains(prefix)) {
            validWords.add(prefix);
        }

        // Marquer la lettre comme visitée
        visited[i][j] = true;

        // Explorer les voisins (adjacents)
        for (int row = i - 1; row <= i + 1; row++) {
            for (int col = j - 1; col <= j + 1; col++) {
                if (row != i || col != j) {
                    dfs(board, row, col, prefix, visited, validWords);
                }
            }
        }

        // Désactiver la visite de la case
        visited[i][j] = false;
    }

    // Méthode pour obtenir le score d'un mot
    public int scoreOf(String word) {
        if (!dictionary.contains(word)) return 0;
        int length = word.length();
        if (length < 3) return 0;
        else if (length < 5) return 1;
        else if (length == 5) return 2;
        else if (length == 6) return 3;
        else if (length == 7) return 5;
        else return 11;
    }

    public static void main(String[] args) {
        In in = new In(args[0]);
        String[] dictionary = in.readAllStrings();
        BoggleSolver solver = new BoggleSolver(dictionary);
        BoggleBoard board = new BoggleBoard(args[1]);
        int score = 0;
        for (String word : solver.getAllValidWords(board)) {
            StdOut.println(word);
            score += solver.scoreOf(word);
        }
        StdOut.println("Score = " + score);
    }

}

